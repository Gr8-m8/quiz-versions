
Starta programet genom "Glosf�rh�r.bat" filen

L�gg .glosa filer i "Moduler" mappen f�r att programet ska kunna ladda dem

Om programet omedelbart avslutas n�r det startar kan det vara bra att ladda ned dotnet sdk:
https://dotnet.microsoft.com/download/thank-you/dotnet-sdk-2.2.104-windows-x64-installer